# Chromaflow

A browser-local ambient instrument combining an incompressible fluid solver and WebAudioFont sampled instruments. Static HTML, CSS and ES modules; no build step or server-side data.

Serve `dist/` with any static HTTP server. Audio starts only after pressing Begin listening. Click or drag to drop color, choose voices and progressions in the panel, or enable automatic rain. Selecting a palette swatch (or pressing 1–4) locks all new painting, rain, and bloom droplets to that color and voice. Enable Cycle colors beside the palette to shuffle all four colors and voices: each appears once per random round, with no consecutive repeats between rounds. This applies to painting, rain, and blooms. The color mode and selected color are remembered. The horizontal impact location selects a chord tone and color chooses the instrument. Space toggles sound, 1–4 selects color, Enter drops when the canvas is focused, and Escape exits Zen view.

Controls include four editable chord slots (via a comma-separated progression), tempo, chord length, 20 instruments assigned to four colors, five soundscape collections, reverb, tempo-synchronized delay, master volume, vorticity, color persistence, droplet size, color cycling, and rain density. Settings persist in localStorage.

The solver uses semi-Lagrangian advection, pressure projection (20 Gauss-Seidel iterations), and vorticity confinement. Desktop uses a 224×156 grid and narrow viewports use a 144×112 grid. Canvas2D renders the dye field plus impact ripples and falling droplets. Audio uses locally bundled WebAudioFont with FluidR3 samples, a filtered feedback delay and a stereo convolution impulse generated in the browser.

Chromaflow source is licensed under GPL-3.0. WebAudioFont is by Sergey Surikov under GPL-3.0; WebAudioFontData has its included notice; FluidR3 GM is by Frank Wen under its included MIT notice. The source download contains all runtime code and sample files. External Google Fonts are optional; system fonts work offline.

The 12 added voices focus on soft attacks: slow strings, synth strings, choir aahs, voice oohs, flute, pan flute, ocarina, and new age, choir, bowed, halo, and sweep pads. Their custom WebAudioFont envelopes swell over 180–750 ms, sustain gently, and release over 1–1.7 seconds. Existing voices retain their original envelopes. The menu groups voices by family, and Soft horizon and Breathing room showcase the new palette. Instruments are loaded and decoded only when selected.

## Optional percussion

The Rhythm tab adds an optional four-lane, sixteen-step beat studio. Choose among warm kick, soft sub, soft snare, rim click, dusty clap, closed hat, shaker, low tom, muted conga, and wood block. Each voice can be muted, given an independent level, or set to No voice. Step buttons cycle off → hit → accent; arrow keys move through the steps. Ocean pulse, Half-time dust, Broken current, Handwoven, and Euclidean drift provide starting patterns. New variation works on the whole beat or a single lane. A lane's hit-count field generates an evenly distributed Euclidean pattern; Rotate shifts it one step. Pattern changes preserve voice choices.

Percussion follows the shared tempo at half, normal, or double speed, with swing, timing/velocity humanization, and its own mix. The Web Audio clock schedules sounds in advance, while animation consumes the corresponding timed hit events. Pausing or disabling percussion stops its scheduler and sources. The chord transport also follows the audio clock. Percussion has independent 0–100% reverb and delay amounts, with one shared eighth-note, dotted-eighth, or quarter-note echo spacing for voices and percussion. The spacing follows effective percussion tempo, including half/double rhythm speed. Change Shared echo spacing in Sound, Rhythm, or Beat studio; all three selectors mirror the saved setting. Voice and drum delay amounts remain independent. Its own convolver reuses the shared impulse buffer, and its own filtered feedback delay is separate from melodic effects. Dry and wet paths pass through the percussion mix control, shared limiter, and master volume, so zero mix and disabling percussion also mute effect tails. These ten percussion voices are synthesized locally with Web Audio; they require no extra sample downloads.

Each rhythm voice sends a pulse from its own place in the canvas. Choose ripples, fluid stirring, or both, and set their strength independently from sound. Stirring adds local vortices to the velocity field without adding dye or triggering melodic notes. Color locking therefore continues to govern all melodic droplets. Percussion settings are saved separately in localStorage under `chromaflow-rhythm-v1`; it is off by default and never starts sound before the scene is played.

Both melodic and percussion delay lines use the same timing function and transition speed. Delay capacity covers the slowest half-time quarter-note setting (four seconds at 30 BPM). Timing remains shared when percussion is switched off.

## Expressive canvas

The Perform tab adds optional expression (on by default at 65% intensity) with a gesture guide, playing-field map, live gesture readout, and an independent Conduct the whole scene switch.

- Position: horizontal placement still chooses a chord tone and now also places it in stereo. High placement is light/bright; low placement adds weight, a warmer low-pass tone, longer sustain, and a larger ink bloom.
- Silk: slow strokes make softer, longer notes and connected fluid ribbons.
- Rush / Spark: speed adds velocity, brighter filtering, shorter envelopes, larger splats, and stronger jets. A fast release sends one final accented droplet.
- Orbit: coherent circular movement creates local vortices. With whole-scene conducting on, it also opens the master filter and moves the composition in stereo.
- Gather / Bloom: hold nearly still for about a second, then release four long, soft chord tones across a small cloud of droplets.
- Conduct: vertical sweeps shape a low-pass filter across both voices and percussion. Downward sweeps warm/darken the composition; upward sweeps open it. Filter, stereo motion, and a gentle level response settle back after release.

Gesture intensity controls the response depth; turning expression off restores basic painting. Reset gesture effects with Let the scene settle. Arrow keys move the canvas's virtual cursor; Enter taps and Shift+Enter releases a bloom. Pointer cancel does not release a bloom; additional concurrent pointers are ignored. Gesture settings persist separately as `chromaflow-expression-v1`.

Manual expressive notes use per-note envelopes, low-pass filters, and stereo positioning, while automatic droplets keep their original note behavior. Filters are inserted before the reusable WebAudioFont gain envelope so its target bus remains stable, and temporary nodes are disconnected when the source ends. Note lengths are bounded at nine seconds; excess polyphony fades older notes. Master gesture filters are separate from the user's volume/effect settings and do not alter the shared delay clock or percussion patterns. Fluid forces are bounded and add no dye. Color locking still applies to every newly launched droplet, including blooms and flicks.
